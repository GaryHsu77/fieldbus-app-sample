/**
 * @file
 * @brief tag object
 *
 */

#ifndef _MXTAGF_H_
#define _MXTAGF_H_

#include <stdint.h>

#ifdef __cplusplus
extern "C"
{
#endif 

const char *
    mxtag_strerror(int errno);

/**
 * @defgroup mxtagf object
 *
 * @ingroup mxtagf
 */

/**
 * @brief tag instance
 *
 * @ingroup mxtagf
 */
typedef struct tag_ tag;

/**
 * @brief Create tag.
 *
 * @ingroup mxtagf
 *
 * @return
 *      Return tag instance.\n
 *      Return NULL on failure.
 *
 * @see
 *      tag_delete()
 */
tag *
    mxtag_new();

/**
 * @brief Create tag with specify IP, port.
 *
 * @ingroup mxtagf
 *
 * @return
 *      Return tag instance.\n
 *      Return NULL on failure.
 *
 * @see
 *      tag_delete()
 */
tag *
    mxtag_new_with_host(
        const char *host
    );

/**
 * @brief Delete tag instance.
 *
 * @ingroup mxtagf
 *
 * @see
 *      mxtag_new()
 */
void
    mxtag_delete(
        tag *self   /**< [in] Instance to be deleted */
    );

/**
 * @brief value
 */
typedef union
{
    int64_t     i;  /**< signed integer */
    uint64_t    u;  /**< unsigned integer */
    float       f;  /**< float */
    double      d;  /**< doube */
    char *      s;  /**< string */
    struct {
        char *  b;  /**< bytearray */
        int     l;  /**< bytearray length */
    };
} value_t;

/**
 * @brief value type.
 */
typedef enum
{
    TAG_VALUE_TYPE_BOOLEAN,
    TAG_VALUE_TYPE_INT8,
    TAG_VALUE_TYPE_INT16,
    TAG_VALUE_TYPE_INT32,
    TAG_VALUE_TYPE_INT,
    TAG_VALUE_TYPE_UINT8,
    TAG_VALUE_TYPE_UINT16,
    TAG_VALUE_TYPE_UINT32,
    TAG_VALUE_TYPE_UINT,
    TAG_VALUE_TYPE_FLOAT,
    TAG_VALUE_TYPE_DOUBLE,
    TAG_VALUE_TYPE_STRING,
    TAG_VALUE_TYPE_BYTEARRAY
} value_type_t;

/**
 * @brief Publish tag.
 *
 * @ingroup mxtagf
 *
 * @return
 *      Return 0 on success.\n
 *      Return -1 on failure.
 *
 * @see
 *      mxtag_subscribe()
 */
int
    mxtag_publish(
        tag *self,                  /**< [in] tag instance */
        const char *source_name,    /**< [in] source Name */
        const char *tag_name,       /**< [in] Tag Name */
        value_t *value,             /**< [in] Value */
        value_type_t value_type,    /**< [in] Value Type */
        const char *unit,           /**< [in] Unit */
        const long long time        /**< [in] Timestamp */
    );

/**
 * @brief Publish single tag and exit.
 *
 * @ingroup mxtagf
 *
 * @return
 *      Return 0 on success.\n
 *      Return -1 on failure.
 *
 * @see
 *      mxtag_subscribe()
 */
int
    mxtag_single_publish(
        const char *source_name,
        const char *tag_name,
        value_t *value,
        value_type_t value_type,
        const char *unit,
        const long long time
    );

/**
 * @brief Publish mqtt raw data.
 *
 * @ingroup mxtagf
 *
 * @return
 *      Return 0 on success.\n
 *      Return -1 on failure.
 */
int
    mxtag_publish_rawdata(
        tag  *self,
        char *topic,
        char *rawdata,
        int  length
    );

/**
 * @brief Subscribe tag.
 *
 * @ingroup mxtagf
 *
 * @return
 *      Return 0 on success.\n
 *      Returne -1 on failure.
 *
 * @see
 *      mxtag_publish() \n
 *      mxtag_unsubscribe() \n
 *      mxtag_subscribe_callback()
 */
int
    mxtag_subscribe(
        tag *self,                  /**< [in] tag instance */
        const char *source_name,    /**< [in] source Name */
        const char *tag_name        /**< [in] Tag Name */
    );

/**
 * @brief Un-Subscribe tag.
 *
 * @ingroup mxtagf 
 *
 * @return
 *      Return 0 on success.\n
 *      Returne -1 on failure.
 *
 * @see
 *      mxtag_subscribe()
 */
int
    mxtag_unsubscribe(
        tag *self,                  /**< [in] tag instance */
        const char *source_name,    /**< [in] source Name */
        const char *tag_name        /**< [in] Tag Name */
    );

/**
 * @brief Subscribe callback function.
 *
 * @ingroup mxtagf
 *
 * @see
 *      mxtag_subscribe() \n
 *      mxtag_subscribe_callback()
 */
typedef
    void (*on_mxtag)(
        tag *self,                  /**< [in] tag instance */
        const char *source_name,    /**< [in] source Name */
        const char *tag_name,       /**< [in] Tag Name */
        value_t *value,             /**< [in] Value */
        value_type_t value_type,    /**< [in] Value Type */
        const char *unit,           /**< [in] unit */
        const long long time        /**< [in] time */
    );

/**
 * @brief Set subscribe callback function.
 *
 * @ingroup mxtagf
 *
 * @return
 *      Return 0 on success.\n
 *      Return -1 on failure.
 *
 * @see
 *      mxtag_subscribe()
 */
int
    mxtag_subscribe_callback(
        tag *self,                      /**< [in] tag instance */
        on_mxtag                        /**< [in] Callback function */
    );

/*
 *  @Brief: transfer data to tag value
 */
value_t *
    mxtag_data_transfer(
        void *			bytes,
        int             size,
        value_type_t    data_type
    );


/*
 *  @Brief: free tag data
 */
void mxtag_data_free(value_t **value);


#ifdef __cplusplus
}
#endif

#endif
