#/bin/bash

# $1 : new fieldbus protocol name (as same as the dest folder name)

echo ""
read -p "Please enter the project name(the best is the name of the protocol) : " name

python ./tool/make_project.py $name
cp ./template/schema.json ./$name/

if [ x"$?" != x"0" ]; then
    echo "create project $name fail. return $?"
    exit 1
fi

echo "********************************************************************"
echo "* Task complete!"
echo "* "
echo "* Then you can start..."
echo "*     1. Modify protocol.json if you need."
echo "*     2. Modify schema.json if you need."
echo "*     3. Autogen project template by build.sh."
echo "********************************************************************"