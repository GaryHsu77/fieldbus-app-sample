#/bin/bash

# $1 : project name

echo ""
echo "clean build project $1 ..."
echo ""

config_json=./$1/config.json

# autogen master_configuration.c ----------------------------------------------------------------------
current_file=./$1/master_configuration.c
rm -rf $current_file

# autogen tag.h ----------------------------------------------------------------------
current_file=./$1/tag.h
rm -rf $current_file

# autogen equipment.h ----------------------------------------------------------------------
current_file=./$1/equipment.h
rm -rf $current_file

# autogen Makefile ----------------------------------------------------------------------
current_file=./$1/Makefile
rm -rf $current_file

rm -rf ./$1/protocol/

current_file=./$1/equipment_hook.c
rm -rf $current_file

current_file=./$1/master.c
rm -rf $current_file

current_file=./$1/tag.c
rm -rf $current_file

if [ x"$?" != x"0" ]; then
    echo "build project $1 fail. return $?"
    exit 1
fi

./build.sh $1