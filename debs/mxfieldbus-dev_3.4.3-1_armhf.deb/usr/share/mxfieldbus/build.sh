#/bin/bash

# $1 : project name

echo ""
echo "Start build project $1 ..."
echo ""

config_json=./$1/schema.json

# autogen master_configuration.c ----------------------------------------------------------------------
current_file=./$1/master_configuration.c
echo "make $current_file ..."
if [ -f "$current_file" ];then
    echo "$current_file already exists"
else
    python ./tool/make_cfg.py ./template/master_configuration.c $config_json $current_file
    if [ x"$?" != x"0" ]; then
        echo "make $current_file fail. return $?"
         exit 1
    fi
fi

# autogen tag.h ----------------------------------------------------------------------
current_file=./$1/tag.h
echo "make $current_file ..."
if [ -f "$current_file" ];then
    echo "$current_file already exists"
else
    python ./tool/make_tagh.py ./template/tag.h $config_json $current_file
    if [ x"$?" != x"0" ]; then
        echo "make $current_file fail. return $?"
         exit 1
    fi
fi

# autogen equipment.h ----------------------------------------------------------------------
current_file=./$1/equipment.h
echo "make $current_file ..."
if [ -f "$current_file" ];then
    echo "$current_file already exists"
else
    python ./tool/make_equh.py ./template/equipment.h $config_json $current_file
    if [ x"$?" != x"0" ]; then
        echo "make $current_file fail. return $?"
         exit 1
    fi
fi

# autogen Makefile ----------------------------------------------------------------------
current_file=./$1/Makefile
echo "make $current_file ..."
if [ -f "$current_file" ];then
    echo "$current_file already exists"
else
    python ./tool/make_mak.py ./template/Makefile $current_file $1
    if [ x"$?" != x"0" ]; then
        echo "make $current_file fail. return $?"
         exit 1
    fi
fi

echo "make ./$1/protocol folder ..."
mkdir -p ./$1/protocol

# autogen fieldbus.py ----------------------------------------------------------------------
current_file=./$1/fieldbus.py
echo "make $current_file ..."
if [ -f "$current_file" ];then
    echo "$current_file already exists"
else
    python ./tool/make_fieldbus.py ./template/protocol/fieldbus.py ./$1/protocol/fieldbus.py  $config_json $1
    if [ x"$?" != x"0" ]; then
        echo "make $current_file fail. return $?"
         exit 1
    fi
fi

current_file=./$1/equipment_hook.c
echo "gen $current_file ..."
if [ -f "$current_file" ];then
    echo "$current_file already exists"
else
    cp ./template/equipment_hook.c ./$1
fi

current_file=./$1/master.c
echo "gen $current_file ..."
if [ -f "$current_file" ];then
    echo "$current_file already exists"
else
    cp ./template/master.c ./$1
fi

current_file=./$1/tag.c
echo "gen $current_file ..."
if [ -f "$current_file" ];then
    echo "$current_file already exists"
else
    cp ./template/tag.c ./$1
fi

if [ x"$?" != x"0" ]; then
    echo "build project $1 fail. return $?"
    exit 1
fi

echo "********************************************************************"
echo "* Task complete!"
echo "* "
echo "* Then you can start..."
echo "*     1. Complete equipment.h."
echo "*     2. Complete tag.h."
echo "*     3. Modify Makefile if you need."
echo "*     4. Complete callbacks that in tag.c."
echo "*     5. Complete callbacks that in equipment_hook.c."
echo "********************************************************************"