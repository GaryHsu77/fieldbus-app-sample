import sys
import re
import json

#argv[1] - script file
#argv[2] - template file
#argv[3] - config file
#argv[4] - output header file

def main(argv):
    
    print 'make %s by %s' % (argv[2], argv[1])

    with open(argv[0]) as f:
        temp_lines = f.readlines()
        temp_lines = [re.sub('(\n)', '', x) for x in temp_lines] 
    
    with open(argv[1]) as f:
        cfg_json = json.loads(f.read())
    
    out_f = open(argv[2], 'w')
    for L in temp_lines:
        if (L.strip() == "@include_fieldbus_equ_item"):
            for item in cfg_json['device']:
                if ('protocol-required' in item['attribute']):
                    if (item['type'] == 'string'):
                        out_f.write('        // ' + item['name'] + '\n')
                        out_f.write('        if ((str = get_string_form_json_object(device, \"' + item['name'] + '\")) != NULL)\n')
                        out_f.write('        {\n')
                        out_f.write('            equ->' + item['name'] + ' = (char *)malloc(strlen(str)+1);\n')
                        out_f.write('            strcpy(equ->' + item['name'] + ', str);\n')
                        out_f.write('            MXLOG_DBUG(\"equipment ' + item['name'] + ' : %s\", equ->' + item['name'] + ');\n')
                        out_f.write('        } \n')
                        out_f.write('        else \n')
                        out_f.write('        { \n')
                        out_f.write('            MXLOG_EROR(\"File[%s] get ' + item['name'] + ' fail.\", CONFIG_FILE); \n')
                        out_f.write('            continue; \n')
                        out_f.write('        }\n\n')
                        
                    if (item['type'] == 'int'):
                        out_f.write('        // ' + item['name'] + '\n')
                        out_f.write('        if ((j_obj = json_object_get(device, \"' + item['name'] + '\")) != NULL)\n')
                        out_f.write('        {\n')
                        out_f.write('            equ->' + item['name'] + ' = json_integer_value(j_obj);\n')
                        out_f.write('            MXLOG_DBUG(\"equipment ' + item['name'] + ' : %d\", equ->' + item['name'] + ');\n')
                        out_f.write('        } \n')
                        out_f.write('        else\n')
                        out_f.write('        { \n')
                        out_f.write('            MXLOG_EROR(\"File[%s] get ' + item['name'] + ' fail.\", CONFIG_FILE); \n')
                        out_f.write('            continue; \n')
                        out_f.write('        }\n')
                    
                    if (item['type'] == 'double'):
                        out_f.write('        // ' + item['name'] + '\n')
                        out_f.write('        if ((j_obj = json_object_get(device, \"' + item['name'] + '\")) != NULL)\n')
                        out_f.write('        {\n')
                        out_f.write('            equ->' + item['name'] + ' = json_real_value(j_obj);\n')
                        out_f.write('            MXLOG_DBUG(\"equipment ' + item['name'] + ' : %lf\", equ->' + item['name'] + ');\n')
                        out_f.write('        } \n')
                        out_f.write('        else\n')
                        out_f.write('        { \n')
                        out_f.write('            MXLOG_EROR(\"File[%s] get ' + item['name'] + ' fail.\", CONFIG_FILE); \n')
                        out_f.write('            continue; \n')
                        out_f.write('        }\n')
                        
                if ('protocol-option' in item['attribute']):
                    if (item['type'] == 'string'):
                        out_f.write('        // ' + item['name'] + '\n')
                        out_f.write('        if ((str = get_string_form_json_object(device, \"' + item['name'] + '\")) != NULL)\n')
                        out_f.write('        {\n')
                        out_f.write('            equ->' + item['name'] + ' = (char *)malloc(strlen(str)+1);\n')
                        out_f.write('            strcpy(equ->' + item['name'] + ', str);\n')
                        out_f.write('            MXLOG_DBUG(\"equipment ' + item['name'] + ' : %s\", equ->' + item['name'] + ');\n')
                        out_f.write('        } \n')
                        out_f.write('        else equ->' + item['name'] + ' = (char *)calloc(1, 2);\n')
                        out_f.write('        \n')
                    
                    if (item['type'] == 'int'):
                        out_f.write('        // ' + item['name'] + '\n')
                        out_f.write('        if ((j_obj = json_object_get(device, \"' + item['name'] + '\")) != NULL)\n')
                        out_f.write('        {\n')
                        out_f.write('            equ->' + item['name'] + ' = json_integer_value(j_obj);\n')
                        out_f.write('            MXLOG_DBUG(\"equipment ' + item['name'] + ' : %d\", equ->' + item['name'] + ');\n')
                        out_f.write('        } \n')
                        out_f.write('        else equ->' + item['name'] + ' = 0;\n')
                        out_f.write('        \n')
                    
                    if (item['type'] == 'double'):
                        out_f.write('        // ' + item['name'] + '\n')
                        out_f.write('        if ((j_obj = json_object_get(device, \"' + item['name'] + '\")) != NULL)\n')
                        out_f.write('        {\n')
                        out_f.write('            equ->' + item['name'] + ' = json_real_value(j_obj);\n')
                        out_f.write('            MXLOG_DBUG(\"equipment ' + item['name'] + ' : %lf\", equ->' + item['name'] + ');\n')
                        out_f.write('        } \n')
                        out_f.write('        else equ->' + item['name'] + ' = 0;\n')
                        out_f.write('        \n')
            continue

        if (L.strip() == "@include_fieldbus_tag_item"):
            for item in cfg_json['tag']:
                if ('protocol-required' in item['attribute']):
                    if (item['type'] == 'string'):
                        out_f.write('    // ' + item['name'] + '\n');
                        out_f.write('    if ((str = get_string_form_json_object(tag_setting, \"' + item['name'] + '\")) != NULL)\n');
                        out_f.write('    {\n');
                        out_f.write('        tag->' + item['name'] + ' = (char *)malloc(strlen(str)+1);\n');
                        out_f.write('        strcpy(tag->' + item['name'] + ', str);\n');
                        out_f.write('        MXLOG_DBUG(\"tag ' + item['name'] + ' : %s\", tag->' + item['name'] + ');\n');
                        out_f.write('    } else return -1;\n')
                        out_f.write('    \n')
            
                    if (item['type'] == 'int'):
                        out_f.write('    // ' + item['name'] + '\n');
                        out_f.write('    if ((j_obj = json_object_get(tag_setting, \"' + item['name'] + '\")) != NULL)\n')
                        out_f.write('    {\n')
                        out_f.write('        tag->' + item['name'] + '  = json_integer_value(j_obj);\n')
                        out_f.write('        MXLOG_DBUG(\"tag ' + item['name'] + ' : %d\", tag->' + item['name'] + ');\n')
                        out_f.write('    }\n')
                        out_f.write('    else return -1;\n')
                        out_f.write('    \n')
                    
                    if (item['type'] == 'double'):
                        out_f.write('    // ' + item['name'] + '\n');
                        out_f.write('    if ((j_obj = json_object_get(tag_setting, \"' + item['name'] + '\")) != NULL)\n')
                        out_f.write('    {\n')
                        out_f.write('        tag->' + item['name'] + '  = json_real_value(j_obj);\n')
                        out_f.write('        MXLOG_DBUG(\"tag ' + item['name'] + ' : %lf\", tag->' + item['name'] + ');\n')
                        out_f.write('    }\n')
                        out_f.write('    else return -1;\n')
                        out_f.write('    \n')
                        
                if ('protocol-option' in item['attribute']):
                    if (item['type'] == 'string'):
                        out_f.write('    // ' + item['name'] + '\n');
                        out_f.write('    if ((str = get_string_form_json_object(tag_setting, \"' + item['name'] + '\")) != NULL)\n');
                        out_f.write('    {\n');
                        out_f.write('        tag->' + item['name'] + ' = (char *)malloc(strlen(str)+1);\n');
                        out_f.write('        strcpy(tag->' + item['name'] + ', str);\n');
                        out_f.write('        MXLOG_DBUG(\"tag ' + item['name'] + ' : %s\", tag->' + item['name'] + ');\n');
                        out_f.write('    }\n')
                        out_f.write('    else tag->' + item['name'] + ' = (char *)calloc(1, 2);\n')
                        out_f.write('    \n')
            
                    if (item['type'] == 'int'):
                        out_f.write('    // ' + item['name'] + '\n');
                        out_f.write('    if ((j_obj = json_object_get(tag_setting, \"' + item['name'] + '\")) != NULL)\n')
                        out_f.write('    {\n')
                        out_f.write('        tag->' + item['name'] + '  = json_integer_value(j_obj);\n')
                        out_f.write('        MXLOG_DBUG(\"tag ' + item['name'] + ' : %d\", tag->' + item['name'] + ');\n')
                        out_f.write('    }\n')
                        out_f.write('    else tag->' + item['name'] + ' = 0;\n')
                        out_f.write('    \n')
                    
                    if (item['type'] == 'double'):
                        out_f.write('    // ' + item['name'] + '\n');
                        out_f.write('    if ((j_obj = json_object_get(tag_setting, \"' + item['name'] + '\")) != NULL)\n')
                        out_f.write('    {\n')
                        out_f.write('        tag->' + item['name'] + '  = json_real_value(j_obj);\n')
                        out_f.write('        MXLOG_DBUG(\"tag ' + item['name'] + ' : %lf\", tag->' + item['name'] + ');\n')
                        out_f.write('    }\n')
                        out_f.write('    else tag->' + item['name'] + ' = 0;\n')
                        out_f.write('    \n')
            continue
        
        if (L.strip() == "@include_fieldbus_tag_free_item"):
            for item in cfg_json['tag']:
                if ('protocol' in item['attribute']):
                    if (item['type'] == 'string'):
                        out_f.write('    if (tag->' + item['name'] + ' != NULL)free(tag->' + item['name'] + ');\n')
            continue
            
        out_f.write(L + '\n');

if __name__ == "__main__":
    main(sys.argv[1:])