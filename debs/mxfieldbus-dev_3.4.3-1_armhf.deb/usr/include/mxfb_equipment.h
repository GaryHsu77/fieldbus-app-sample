#ifndef MXFB_EQUIPMENT_H 
#define MXFB_EQUIPMENT_H

#include "mxfb_tag.h"
#include "mxfb_scheduler.h"

//=============================================================================
// Moxa ThingsPro common equipment struct item.
//=====================================================================================
#define COMMON_EQU_ITEM     char                        *name;                        \
                            char                        *interface;                   \
                            char                        *template_name;               \
                            tag                         *tag_ctx;                     \
                            pthread_mutex_t             *mutex;                       \
                            int                         tag_count;                    \
                            Tag                         *tags;                        \
                            Tag_group                   *t_groups;                    \
                            long long                   polling_count;                \
/*--------------------------------------------------------------------------------*/  \
                            EQU_INIT                    init;                         \
                            EQU_GET_TAG                 get_tag;                      \
                            EQU_START_CALLBACK          start;                        \
                            EQU_STOP_CALLBACK           stop;                         \
                            EQU_IS_WARNING_CALLBACK     is_warning;                   \
                            EQU_RECONNECT_CALLBACK      restart;                      \
                            EQU_TASK_INSERT_CALLBACK    task_insert;                  \
                            EQU_LOCK                    lock;                         \
                            EQU_UNLOCK                  unlock;                       \
/*--------------------------------------------------------------------------------*/  \
                            EQU_TAG_POLLING_HOOK        tag_polling_hook;             \
                            EQU_TGROUP_POLLING_HOOK     tag_group_polling_hook;       \
                            EQU_TGROUP_POLLING_END_HOOK tag_group_polling_end_hook;   \
                            EQU_RESTART_HOOK            restart_hook;                 \
                            EQU_IS_WARNING_HOOK         is_warning_hook;              \
                            EQU_STOP_HOOK               stop_hook;                    \
                            EQU_START_HOOK              start_hook;                   \
                            EQU_INIT_HOOK               init_hook;                    \
                            EQU_TASK_INSERT_HOOK        task_insert_hook;             \
                            char                        reserved[0x10];

#pragma pack (1)
//Divide every tag with polling_period_ms.
//Every tag in this group has the same polling_period_ms
typedef struct
{
    void                    *equipment;
    int                     tag_count;
    Tag                     **tags;
    Polling_scheduler       scheduler;
} Tag_group;
#pragma pack ()

typedef int    (*EQU_INIT)                    (void *this);
typedef Tag*   (*EQU_GET_TAG)                 (void *this, char *tag_name);
typedef int    (*EQU_START_CALLBACK)          (void *this);
typedef int    (*EQU_STOP_CALLBACK)           (void *this);
typedef int    (*EQU_IS_WARNING_CALLBACK)     (void *this);
typedef int    (*EQU_RECONNECT_CALLBACK)      (void *this);
typedef Value* (*EQU_TASK_INSERT_CALLBACK)    (void *this, Tag *tag, uint8_t *buffer, int buffer_size);
typedef  int   (*EQU_LOCK)                    (void *this);
typedef  int   (*EQU_UNLOCK)                  (void *this);
typedef Value* (*EQU_TAG_POLLING_HOOK)        (void *this, Tag *tag);
typedef int    (*EQU_TGROUP_POLLING_HOOK)     (void *this, Tag_group *t_group);
typedef int    (*EQU_TGROUP_POLLING_END_HOOK) (void *this, Tag_group *t_group);
typedef int    (*EQU_RESTART_HOOK)            (void *this);
typedef int    (*EQU_IS_WARNING_HOOK)         (void *this);
typedef int    (*EQU_STOP_HOOK)               (void *this);
typedef int    (*EQU_START_HOOK)              (void *this);
typedef int    (*EQU_INIT_HOOK)               (void *this);
typedef Value* (*EQU_TASK_INSERT_HOOK)        (void *this, Tag *tag, uint8_t *buffer, int buffer_size);

#endif