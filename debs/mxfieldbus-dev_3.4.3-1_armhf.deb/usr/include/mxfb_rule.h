#ifndef MX_RULE_H 
#define MX_RULE_H

#include "mxfb.h"
#include "tag.h"

Value *auto_scaling_handler (
    Tag     *tag,
    Value   *value
    );
    
Value *byte_order_handler (
    Tag     *tag,
    Value   *value
    );
    
Value *mx_rule_handler(
    Tag     *tag,
    Value   *value;
    );
    
#endif