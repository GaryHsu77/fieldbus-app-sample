#ifndef MX_EQU_HOOK_H 
#define MX_EQU_HOOK_H

/*
* mxequipment_init: 
*          setup Equipment object and assign user init hook.
* INPUT: 
*     Equipment *equ :
*          Need is a valid equipment point.
*     EQU_INIT_HOOK init_hook: 
*          The function pointer that User implement. 
*/
int mxequipment_init(
        Equipment *equ, 
        EQU_INIT_HOOK init_hook
        );

int mxfb_api_listener (
        Mx_zmq_broker *zmq, 
        Equipment *all_equipment_list, 
        int equ_size, 
        int equipment_count
        );

int mxequipment_start_hook_set (
        Equipment *equ, 
        EQU_START_HOOK equ_start_hook
        );
        
int mxequipment_stop_hook_set (
        Equipment *equ, 
        EQU_STOP_HOOK equ_stop_hook
        );

int mxequipment_is_warning_hook_set (
        Equipment *equ, 
        EQU_IS_WARNING_HOOK equ_is_warning_hook
        );

int mxequipment_restart_hook_set (
        Equipment *equ, 
        EQU_RESTART_HOOK equ_restart_hook
        );

int mxequipment_tag_polling_hook_set (
        Equipment *equ, 
        EQU_TAG_POLLING_HOOK tag_polling_hook
        );
        
int mxequipment_task_insert_hook_set (
        Equipment *equ, 
        EQU_TASK_INSERT_HOOK equ_task_insert_hook
        );
        
int mxequipment_tag_group_polling_hook_set (
        Equipment *equ, 
        EQU_TGROUP_POLLING_HOOK tag_group_polling_hook
        );

int mxequipment_tag_group_polling_end_hook_set (
        Equipment *equ, 
        EQU_TGROUP_POLLING_END_HOOK tag_group_polling_end_hook
        );

#endif