#ifndef _MX_LOG_H_
#define _MX_LOG_H_

#include <syslog.h>
#include <stdio.h>

#define DEV_DBG 1

/* follow syslog.h */
// #define LOG_EMERG   0   /* system is unusable */
// #define LOG_ALERT   1   /* action must be taken immediately */
// #define LOG_CRIT    2   /* critical conditions */
// #define LOG_ERR     3   /* error conditions */
// #define LOG_WARNING 4   /* warning conditions */
// #define LOG_NOTICE  5   /* normal but significant condition */
// #define LOG_INFO    6   /* informational */
// #define LOG_DEBUG   7   /* debug-level messages */

typedef enum {
    MX_LOG_DEBUG   = 0x01,
    MX_LOG_INFO    = 0x02,
    MX_LOG_WARNING = 0x03,
    MX_LOG_ERR     = 0x04
} LOG_LEVEL;

#define MXLOG_DBUG(fmt, args...) \
    do{ \
        char __msg__[1024]; \
        sprintf(__msg__, fmt, ##args); \
        mxlog_log(MX_LOG_DEBUG, __FILE__, __LINE__, __msg__); \
    }while(0)

#define MXLOG_INFO(fmt, args...) \
    do{ \
        char __msg__[1024]; \
        sprintf(__msg__, fmt, ##args); \
        mxlog_log(MX_LOG_INFO, __FILE__, __LINE__, __msg__); \
    }while(0)

#define MXLOG_WARN(fmt, args...) \
    do{ \
        char __msg__[1024]; \
        sprintf(__msg__, fmt, ##args); \
        mxlog_log(MX_LOG_WARNING, __FILE__, __LINE__, __msg__); \
    }while(0)

#define MXLOG_EROR(fmt, args...) \
    do{ \
        char __msg__[1024]; \
        sprintf(__msg__, fmt, ##args); \
        mxlog_log(MX_LOG_ERR, __FILE__, __LINE__, __msg__); \
    }while(0)

extern int mxlog_log(LOG_LEVEL level, char *file, int line, char *msg);
extern int mxlog_init(char *ident, int debug);
extern int mxlog_close();
extern int mxlog_debug_on();
extern int is_mxlog_debug_mode();
#endif