#ifndef MXFBI_INTERFACE_H 
#define MXFBI_INTERFACE_H

#include "mxfb.h"
#include <pthread.h>

typedef void* mxfbi_t;

typedef  int   (*MXFBI_READ_TAG_CALLBACK)  (char *device_name, char *tag_name, value_t* value, value_type_t* value_type, void *usr_data);
typedef  int   (*MXFBI_WRITE_TAG_CALLBACK) (char *device_name, char *tag_name, value_t value, value_type_t value_type, void *usr_data);
typedef  char* (*MXFBI_STATUS_CALLBACK)    (void *usr_data);

mxfbi_t *mxfbi_new ();

int mxfbi_read_tag_callback_set(
        mxfbi_t *mxfbi,
        void *usr_data,
        MXFBI_READ_TAG_CALLBACK callback
        );

int mxfbi_write_tag_callback_set(
        mxfbi_t *mxfbi,
        void *usr_data,
        MXFBI_WRITE_TAG_CALLBACK callback
        );

int mxfbi_status_callback_set(
        mxfbi_t *mxfbi,
        void *usr_data,
        MXFBI_STATUS_CALLBACK callback
        );

int mxfbi_start (
        mxfbi_t *mxfbi
        );

int mxfbi_delete (
        mxfbi_t *mxfbi
        );

#endif