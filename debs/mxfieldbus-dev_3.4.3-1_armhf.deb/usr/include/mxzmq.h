#ifndef MX_ZMQ_H 
#define MX_ZMQ_H

#include <zmq.h>
#include <inttypes.h>
#include <assert.h>
#include <signal.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/time.h>
#include "mxfb_log.h"

#define ZMQ_TIMEOUT_SEC         5
#define REQ_CMD_EQU_NAME_SIZE   128
#define REQ_CMD_TAG_NAME_SIZE   128
#define REQ_CMD_BUFFER_SIZE     1024*2

// client request status code
typedef enum {
    REP_SUCCESS                 = 0,
    REP_INCORRECT_CMD           = 1,
    REP_EQU_NOTFOUND            = 2,
    REP_TAG_NOTFOUND            = 3,
    REP_TAG_OP_MISMATCH         = 4,
    REP_TASK_INSERT_ERROR       = 5,
    REP_SEND_TIMEOUT            = 6,
    REP_RECV_TIMEOUT            = 7,
    REP_RECV_CID_ERROR          = 8,
    REP_RECV_NO_DATA            = 9,
    REP_PARAMETER_ERROR         = 10,
    REP_CMD_BUFFER_TOO_SMALL    = 11,
    REP_SERVICE_NOTFOUND        = 12
} Rep_status;

typedef enum {
    ZMQ_NORMAL,
    NEED_ZMQ_RECONNECT
} Zmq_status;

#pragma pack (1)
typedef struct
{   
    char client_id[10];
    int op;
    int time_out_sec;
    int equ_name_size;
    int tag_name_size;
    int cmd_buffer_size;
    int value_type;
    char command[REQ_CMD_EQU_NAME_SIZE + REQ_CMD_TAG_NAME_SIZE + 1 + REQ_CMD_BUFFER_SIZE + 1]; //equ_nametag_name
} Mx_zmq_req;

typedef struct
{
    char client_id[10];
    int status;
    int tag_t;
    int value_t;
    int value_size;
    char value[1];
} Mx_zmq_rep;
#pragma pack ()

typedef int     (*ZMQ_BIND)         (void *this);
typedef int     (*ZMQ_B_REBIND)     (void *this);
typedef int     (*ZMQ_C_REBIND)     (void *this, int timeout_ms);
typedef int     (*ZMQ_SEND)         (void *this, char *msg, int size);
typedef int     (*ZMQ_RECV_REQ)     (void *this, char *result);
typedef int     (*EMQ_RELEASE)      (void *this);
typedef int     (*EMQ_CLOSE)        (void *this);
typedef int     (*ZMQ_SEND_REQ)     (void *this, Mx_zmq_req  *req_cmd);
typedef int     (*ZMQ_RECV_REP)     (void *this, char **buffer);
typedef int     (*ZMQ_SET_TIMEOUT)  (void *this, int timeout_ms);

#pragma pack (1)
typedef struct
{   
    void            *context;
    void            *broker;
    char            *bind_ip_address;
    unsigned short  bind_port;
    int             recv_timeout;
    Zmq_status      status;
    ZMQ_BIND        bind;
    ZMQ_B_REBIND    rebind;
    ZMQ_RECV_REQ    recv_req;
    ZMQ_SEND        send;
    EMQ_RELEASE     release;
} Mx_zmq_broker;

typedef struct
{   
    void            *context;
    void            *client;
    char            *client_id;
    char            *ip_address;
    unsigned short  port;
    int             timeout_ms;
    Zmq_status      status;
    ZMQ_BIND        bind;
    ZMQ_C_REBIND    rebind;
    ZMQ_SEND_REQ    send_request;
    ZMQ_RECV_REP    recv_reply;
    EMQ_RELEASE     release;
    EMQ_CLOSE       close;
    ZMQ_SET_TIMEOUT set_timeout;
} Mx_zmq_client;
#pragma pack ()

Mx_zmq_broker *Mx_zmq_ipc_broker_setup(
                    char *bind_ip_address,
                    unsigned short bind_port,
                    int timeout_sec
                    );
                    
Mx_zmq_client *Mx_zmq_ipc_client_setup(
                    const char* ip_address,
                    unsigned short port,
                    int timeout_ms
                    );
                    
#endif