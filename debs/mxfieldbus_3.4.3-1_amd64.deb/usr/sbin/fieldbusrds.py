#!/usr/bin/env python
import os
import sys
import ast
import redis

class fieldbusRedis():
    def __init__(self, host='localhost', port=6379):
        self.host = host
        self.port = port

    def __enter__(self):
        connectionPool = redis.ConnectionPool(host=self.host, port=self.port)
        if connectionPool is None:
            print "Failed to establish redis connection"
            return None
        self.rds = redis.StrictRedis(connection_pool=connectionPool)
        return self

    def __exit__(self, type, value, traceback):
        if hasattr(self, 'rds'):
            self.rds.connection_pool.disconnect()

    def get_configs(self, protocol="*"):
        protocols=[]
        try:
            # get key set about fieldbus in database
            for key in self.rds.scan_iter("fieldbusApp:{}".format(protocol)):
                fields = self.rds.hgetall(key)
                protocolName = self.scan_protocol_message(fields)
                if protocolName is not None:
                    protocols.append(protocolName)
        except Exception as err:
             print "Failed to onnect to redis server: " + str(err)
        return protocols

    def scan_protocol_message(self, protocol):
        protocolName = None
        for key in protocol.keys():
            protocolName = protocol[key] \
                if key == "name" else self.set_config(key, protocol[key])
        return protocolName

    def set_config(self, path, content):
        if not os.path.exists(os.path.dirname(path)):
            os.makedirs(os.path.dirname(path), 0755)
        with open(path, 'w+') as f:
            f.write(content)
