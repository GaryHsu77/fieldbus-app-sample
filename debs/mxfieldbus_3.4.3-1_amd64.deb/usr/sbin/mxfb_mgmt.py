#!/usr/bin/env python
import sys
import json
import os
import imp
import inspect
import uuid

from optparse import OptionParser
from fieldbusrds import fieldbusRedis

mxfb_protocol_path = '/etc/mxfieldbus/protocol.d'
configuration = '/etc/mxfieldbus/db.json'


def parse_options():
    global g_verbose
    parser = OptionParser(usage='usage: ', version='%prog 1.0', description='')
    parser.add_option('-p', '--protocol',      action='store',
                      dest='protocol',      default='',      help='')
    parser.add_option('',   '--device_add',       action='store',        dest='device_add',
                      default='',      help='--device_add={device json file path}')
    parser.add_option('',   '--device_edit',      action='store',        dest='device_edit',
                      default='',      help='--device_edit={device json file path}')
    parser.add_option('',   '--device_remove',    action='store',
                      dest='device_remove',    default='',      help='--device_remove={device_name}')
    parser.add_option('',   '--tmp_list',      action='store_true',   dest='tmp_list',
                      default='False',  help='get all template list of the specified protocol')
    parser.add_option('',   '--tmp_get',       action='store',
                      dest='tmp_get',       default='',      help='--tmp_get={template name}')
    parser.add_option('',   '--tmp_add',       action='store',        dest='tmp_add',
                      default='',      help='--tmp_add={template json file path}')
    parser.add_option('',   '--tmp_edit',      action='store',        dest='tmp_edit',
                      default='',      help='--tmp_edit={template json file path}')
    parser.add_option('',   '--tmp_remove',    action='store',
                      dest='tmp_remove',    default='',      help='--tmp_remove={template id}')
    parser.add_option('',   '--tag_list',      action='store_true',
                      dest='tag_list',      default='False', help='get all tag list')
    parser.add_option('',   '--protocol_list', action='store_true',
                      dest='protocol_list', default='False', help='get all protocol list')
    parser.add_option('',   '--status',        action='store_true',   dest='status',
                      default='False', help='get protocol device status')
    parser.add_option('',   '--device_list', action='store_true',
                      dest='device_list', default='False', help='get all device list')
    parser.add_option('',   '--test',          action='store',        dest='test',
                      default='',      help='test connection by input an device json obj')
    parser.add_option('',   '--start', action='store_true', dest='start',
                      default='False', help='start service')
    parser.add_option('',   '--stop', action='store_true', dest='stop',
                      default='False', help='stop service')
    parser.add_option('',   '--init', action='store', dest='init',
                      default='', help='reload fieldbus configs with specific protocol')
    parser.add_option('', '--redis_host',      action='store',
                      dest='redis_host',      default='',      help='')
    options, args = parser.parse_args()
    return options, args


def db_add_device(add_json, protocol_name):
    db_json = load_json_obj_from_config(configuration)
    for db_dev in db_json['deviceList']:
        if db_dev['name'] != add_json['name']:
            continue
        print 'Device[%s] has been added.' % (add_json['name'])
        return -1
    protocols = json.loads('{}')
    protocols['protocol'] = protocol_name
    protocols['id'] = add_json['id']
    protocols['name'] = add_json['name']

    db_json['deviceList'].append(protocols)
    with open(configuration, 'w') as outfile:
        json.dump(db_json, outfile, indent=4)
    return 0

def db_rm_devices(rm_json, protocol_name):
    db_json = load_json_obj_from_config(configuration)
    
    for rm_dev in rm_json['deviceList']:
        index = 0
        for db_dev in db_json['deviceList']:
            if (db_dev['id'] == rm_dev['id']):
                del db_json['deviceList'][index]
                break
            else:
                index += 1

    with open(configuration, 'w') as outfile:
        json.dump(db_json, outfile, indent=4)
    return 0

def get_protocol_list():
    protocols = json.loads('{\"protocolList\" : []}')
    for f in os.listdir(mxfb_protocol_path):
        p_json = load_json_obj_from_config(
            mxfb_protocol_path + '/' + f + '/protocol.json')
        if (p_json == None):
            continue
        protocols['protocolList'].append(p_json)

    return protocols

def get_device_list(protocol_name):
    # get protocol cfg path
    for f in os.listdir(mxfb_protocol_path):
        p_json = load_json_obj_from_config(
            mxfb_protocol_path + '/' + f + '/protocol.json')
        if (p_json == None):
            continue
        if p_json['protocolName'] != protocol_name:
            continue
        fieldbus_class = load_fieldbus_class(p_json['protocolName'])
        fieldbus = fieldbus_class()
        protocol_devices = fieldbus.get_device_list(p_json['protocolName'])
        return protocol_devices
    return {}

def get_tag_list():
    tags = json.loads('{\"tagList\" : []}')

    for f in os.listdir(mxfb_protocol_path):
        p_json = load_json_obj_from_config(
            mxfb_protocol_path + '/' + f + '/protocol.json')
        if (p_json == None):
            continue
        fieldbus_class = load_fieldbus_class(p_json['protocolName'])
        fieldbus = fieldbus_class()
        protocol_tags = fieldbus.get_tag_list()
        for protocol_tag in protocol_tags['tagList']:
            tags['tagList'].append(protocol_tag)

    return tags


def load_json_obj_from_config(file):
    if (len(file) <= 0):
        print 'please input json format file.'
        return None
    if not os.path.isfile(file):
        return None

    with open(file) as f:
        cfg_json = json.loads(f.read())

    return cfg_json


def get_mxfb_class(class_name, pyfile):

    def predicate(member):
        return inspect.isclass(member)

    # dynamic load import module via property "main" in bundle config
    module = imp.load_source(class_name, pyfile)
    result = inspect.getmembers(module, predicate)

    for classObj in result:
        return classObj[1]

    return None


def load_fieldbus_class(protocol_name):
    interface_path = mxfb_protocol_path + '/' + protocol_name


    pyfile = os.path.join(interface_path, 'fieldbus.py')
    bundleClass = get_mxfb_class("Fieldbus", pyfile)
    if bundleClass is None:
        raise RuntimeError("Couldn't find fieldbus subclass in " + pyfile)

    return bundleClass


def load_fieldbus_configs(protocol_name):
    with fieldbusRedis(host='core-redis') as rds:
        if rds is None: return None
        return rds.get_configs(protocol_name)


def main(argv):
    options, args = parse_options()

    if not os.path.exists(mxfb_protocol_path):
        os.makedirs(mxfb_protocol_path)

    rc = -1
    # tag_list --------------------------------
    if (options.tag_list == True):
        tags = get_tag_list()
        print json.dumps(tags)
        return sys.exit(0)

    # protocol_list --------------------------------
    if (options.protocol_list == True):
        protocols = get_protocol_list()
        print json.dumps(protocols)
        return sys.exit(0)

    # load_configs --------------------------------
    if (options.init):
        ret = load_fieldbus_configs(options.init)
        if ret is not None: return sys.exit(0)
        else: return sys.exit(1)

    protocol_name = options.protocol
    if (len(protocol_name) == 0):
        print 'Please input protocol name'
        return sys.exit(-1)

    fieldbus = None
    fieldbus_class = load_fieldbus_class(protocol_name)
    redis_host = options.redis_host
    if (len(redis_host) != 0):
        fieldbus = fieldbus_class(redis_host, 6379)
    else:
        fieldbus = fieldbus_class()

    if (fieldbus == None):
        print 'The protocol isn\'t available'
        return sys.exit(-1)

    # device_add --------------------------------
    if (options.device_add):
        dev_add_json = load_json_obj_from_config(options.device_add)
        if (dev_add_json == None):
            print 'add device file.[invalid json].'
        else:
            dev_add_json['id'] = str(uuid.uuid1()) # assign a unique id to device
            rc = db_add_device(dev_add_json, protocol_name)
            if (rc == 0):
                rc = fieldbus.add_device(dev_add_json)
                if (rc != 0):
                    error_handle_add = json.loads('{\"deviceList\" : []}')
                    error_handle_add['deviceList'].append(dev_add_json)
                    rc = db_rm_devices(error_handle_add, protocol_name)

    # device_edit --------------------------------
    elif (options.device_edit):
        dev_edit_json = load_json_obj_from_config(options.device_edit)
        if (dev_edit_json == None):
            print 'add device file.[invalid json].'
        else:
            db_json = load_json_obj_from_config(configuration)
            for edit_dev in dev_edit_json['deviceList']:
                for db_dev in db_json['deviceList']:
                    if (db_dev['id'] == edit_dev['id']):
                        db_dev['name'] = edit_dev['name']
                        break

            # check if any duplicate device name in db_json
            check_duplicate_name = {}
            for db_dev in db_json['deviceList']:
                if not (check_duplicate_name.has_key(db_dev['name'])):
                    check_duplicate_name[db_dev['name']] = 1
                    continue
                print 'edit_dev(): dupicate device name is not allowed'
                return sys.exit(-1)

            rc = fieldbus.edit_device(dev_edit_json)
            if (rc == 0):
                with open(configuration, 'w') as outfile:
                    json.dump(db_json, outfile, indent=4)

    # device_remove ------------------------------
    elif (options.device_remove):
        dev_remove_json = load_json_obj_from_config(options.device_remove)
        rc = fieldbus.remove_device(dev_remove_json)
        if (rc == 0):
            db_rm_devices(dev_remove_json, protocol_name)

    # tmp_list --------------------------------
    elif (options.tmp_list == True):
        tmps = fieldbus.get_template_list()
        if (tmps):
            print json.dumps(tmps)
            rc = 0

    # tmp_get ---------------------------------
    elif (options.tmp_get):
        tmps = fieldbus.get_template(options.tmp_get)
        if (tmps):
            print json.dumps(tmps)
            rc = 0

    # tmp_add ---------------------------------
    elif (options.tmp_add):
        rc = fieldbus.add_template(options.tmp_add)

    # tmp_edit --------------------------------
    elif (options.tmp_edit):
        rc = fieldbus.edit_template(options.tmp_edit)

    # tmp_remove ------------------------------
    elif (len(options.tmp_remove) > 0):
        rc = fieldbus.remove_template(options.tmp_remove)

    # status ------------------------------
    elif (options.status == True):
        ret_status = fieldbus.get_status(protocol_name)
        try:
            json.loads(ret_status)
            print ret_status
            rc = 0
        except:
            rc = -1

    # test ------------------------------
    elif (len(options.test) > 0):
        rc = fieldbus.device_test(protocol_name, options.test)

    # device_list ---------------------------
    elif (options.device_list == True):
        device_list = get_device_list(protocol_name)
        if (device_list):
            print json.dumps(device_list)
            rc = 0
    # start ---------------------------
    elif (options.start == True):
        rc = fieldbus.start()
    # stop ---------------------------
    elif (options.stop == True):
        rc = fieldbus.stop()
    sys.exit(rc)


if __name__ == "__main__":
    main(sys.argv[1:])
