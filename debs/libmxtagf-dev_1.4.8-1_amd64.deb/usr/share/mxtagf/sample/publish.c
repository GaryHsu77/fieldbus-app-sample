#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <mxtagf.h>
#include <signal.h>

int main(
         int argc,
         const char *argv[])
{
    tag *tag_ = mxtag_new();

    value_t volt;
    volt.f = 1.414;

    mxtag_publish(
        tag_,
        "electricity",
        "voltage",
        &volt,
        TAG_VALUE_TYPE_FLOAT,
        "v",
        1542457755795);

    mxtag_delete(tag_);

    return 0;
}
