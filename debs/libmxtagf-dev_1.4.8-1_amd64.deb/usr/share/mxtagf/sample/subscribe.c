#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include <mxtagf.h>

void
    on_tag_callback(
        tag *self,
        const char *equipment_name,
        const char *tag_name,
        value_t *value,
        value_type_t value_type,
        const char *unit,
        const long long at)
{
    printf("Equ: %s, ", equipment_name);
    printf("Tag: %s, ", tag_name);
    printf("Value: ");
    if (value_type == TAG_VALUE_TYPE_INT || value_type == TAG_VALUE_TYPE_INT32 ||
            value_type == TAG_VALUE_TYPE_INT16 || value_type == TAG_VALUE_TYPE_INT8) {
        printf("%" PRId64 ", ", value->i);
    }
    else if (value_type == TAG_VALUE_TYPE_UINT || value_type == TAG_VALUE_TYPE_UINT32 ||
            value_type == TAG_VALUE_TYPE_UINT16 || value_type == TAG_VALUE_TYPE_UINT8)
        printf("%" PRIu64 ", ", value->u);
    else if (value_type == TAG_VALUE_TYPE_FLOAT)
        printf("%f, ", value->f);
    else if (value_type == TAG_VALUE_TYPE_DOUBLE)
        printf("%lf, ", value->d);
    else if (value_type == TAG_VALUE_TYPE_STRING)
    {
        printf("%s, ", value->s);
    }
    else if (value_type == TAG_VALUE_TYPE_BYTEARRAY)
    {
        size_t i;
        for(i = 0; i < value->l; i++)
        {
            printf("%02x", value->b[i]);
        }
        printf(", ");
    }
    else {
        printf(", ");
    }
    printf("Time: %lld, ", at);
    printf("Unit: %s\n", unit);
}

int
    main(
        int argc,
        const char *argv[])
{
    tag *tag_ = mxtag_new();

    mxtag_subscribe_callback(tag_, on_tag_callback);

    mxtag_subscribe(tag_, "+", "+");
    for(;;)
    {
        sleep(1);
    }

    mxtag_delete(tag_);

    return 0;
}
