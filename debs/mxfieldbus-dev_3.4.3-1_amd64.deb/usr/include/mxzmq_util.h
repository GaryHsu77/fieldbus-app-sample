#ifndef MX_ZMQ_UTIL_H 
#define MX_ZMQ_UTIL_H

#include "mxzmq.h"
#include "mxfb.h" 

//---------------------------------------------------------------------------
// fieldbus framework utils.
//---------------------------------------------------------------------------
static Value *reply_to_value(Mx_zmq_rep *rep)
{
    Value *value;
    
    value           = (Value *)malloc(sizeof(Value));
    value->size     = rep->value_size;
    value->type_t   = rep->value_t;
    value->payload  = (uint8_t *)malloc(rep->value_size);
    memcpy(value->payload, rep->value, value->size);
    return value;
}

static int send_reply_buffer(Mx_zmq_broker *zmq, Value *value, int tag_t, char *client_id, int ret_status)
{
    Mx_zmq_rep  *rep_ret;
    int         payload_size    = 0;
    int         buffersize      = sizeof(Mx_zmq_rep);
    
    if (value != NULL)
    {
        payload_size        = value->size;
        buffersize          = sizeof(Mx_zmq_rep) - 1 + payload_size;
        rep_ret             = (Mx_zmq_rep *)malloc(buffersize);
        rep_ret->value_t    = value->type_t;
        rep_ret->value_size = value->size;
        memcpy(rep_ret->value, value->payload, payload_size);
    }
    else rep_ret = (Mx_zmq_rep *)malloc(sizeof(Mx_zmq_rep));

    rep_ret->status = ret_status;
    rep_ret->tag_t  = tag_t;
    strcpy(rep_ret->client_id, client_id);
    
    zmq->send(zmq, (char*)rep_ret, buffersize);
    free(rep_ret);
    return 0;
}

static int make_request_cmd(
    Mx_zmq_req      *req_cmd, 
    const char      *equipment_name,
    const char      *tag_name,
    Operate_t       op, 
    char            *client_id, 
    int             timeout_ms,
    uint8_t         *buffer, 
    int             buffer_size
    )
{
    strcpy(req_cmd->client_id, client_id);
    req_cmd->time_out_sec    = (timeout_ms/1000)+((timeout_ms%1000)>0 ? 1:0);
    req_cmd->op              = op;
    req_cmd->equ_name_size   = strlen(equipment_name);
    req_cmd->tag_name_size   = strlen(tag_name);
    req_cmd->cmd_buffer_size = 0;
    memset(req_cmd->command, 0, REQ_CMD_BUFFER_SIZE);
    strcpy(req_cmd->command, equipment_name);
    strcat(req_cmd->command, tag_name);
    
    // command :$(equ_name)+$(tag_name)+'\0'+$(buffer)+'\0'
    if ((op == MXFB_WRITE) && (buffer_size != 0))
    {
        char *write_ptr = (char *)(req_cmd->command+strlen(req_cmd->command)+1);
        req_cmd->cmd_buffer_size = buffer_size;
        memcpy(write_ptr, buffer, buffer_size);
    }
    else if ((op == MXFB_TEST) && (buffer_size != 0))
    {
        char *json_ptr = (char *)(req_cmd->command+strlen(req_cmd->command)+1);
        req_cmd->cmd_buffer_size = strlen((char*)buffer)+1;
        strcpy (json_ptr, (char*)buffer);
    }
    
    return 0;
}

#endif