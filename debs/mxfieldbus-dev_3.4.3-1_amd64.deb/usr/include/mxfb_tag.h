#ifndef MXFB_TAG_H 
#define MXFB_TAG_H

#include "mxfb.h"

//=============================================================================
// Moxa ThingsPro common tag struct item.
//=============================================================================
#define COMMON_TAG_ITEM     int                 version;            \
                            char                *id;                \
                            char                *op;                \
                            char                *type;              \
                            char                *unit;              \
                            char                *byte_order;        \
                            double              slope;              \
                            double              offset;             \
                            int                 interframe_delay_ms;\
                            tag                 *tag_ctx;           \
                            int                 request_timeout_ms; \
                            int                 polling_period_ms;  \
                            TAG_DO_COMMAND      do_command;         \
                            TAG_CHECK           check;              \
                            char                *last_polling_ts;   \
                            char                *last_success_ts;   \
                            int                 polling_status;     \
                            char                reserved[0x10];

typedef  Value* (*TAG_DO_COMMAND)   (void *tag, uint8_t *write_buffer, int write_size);
typedef  int    (*TAG_CHECK)        (void *tag, Operate_t op_t);

#endif