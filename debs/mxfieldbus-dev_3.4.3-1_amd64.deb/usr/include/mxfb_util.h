#ifndef MXFB_UTIL_H 
#define MXFB_UTIL_H

#include <jansson.h>
#include "mxfb.h"

int set_master_pid (
            char *pid_file
            );

Value *mx_value_new (
            value_type_t type, 
            uint8_t *buffer, 
            int buffer_size
            );

int mx_value_free (
            Value *value
            );

char *string_u16_to_u8(
            uint16_t* str, 
            int size
            );

char *value_to_string (
            Value *value
            );
            
value_type_t get_type_by_str (
            char *type_str
            );

Operate_t get_op_by_str (
            char *op_str
            );

int is_regular_file (
            const char *path
            );

int isDirectory (
            const char *path
            );

int get_int_form_json_object (
            json_t *parent_jobj, 
            char *title
            );

char *get_string_form_json_object (
            json_t *parent_jobj, 
            char *title
            );

int current_timestamp (
            long long *timestamp
            );
            
int mx_value_v2_transfer (
            uint8_t *value_data, 
            int value_data_type, 
            int value_data_size, 
            value_t *value, 
            value_type_t *value_type
            );
#endif