#ifndef MXFB_API_H 
#define MXFB_API_H

#include "mxtagf.h"

#pragma pack (1)
typedef struct
{   
    char  *device_name;
    unsigned short  port;
    char  *device_list_result;
    void  *ctx;
} mxfb_t;
#pragma pack ()

mxfb_t*     mxfb_new ();
mxfb_t*     mxfb_new_by_devlist (char* dev_json_file);

void        mxfb_delete (
                mxfb_t *self
                );

int         mxfb_read(
                mxfb_t         *self,
                const char      *device_name,
                const char      *tag_name,
                int             timeout_ms,
                value_t         *value,
                value_type_t    *value_type
                );

int         mxfb_write(
                mxfb_t *self,
                const char *device_name,
                const char *tag_name,
                int timeout_ms,
                value_t value,
                value_type_t value_type
                );

char*       mxfb_status(
                mxfb_t *self,
                const char      *protocol_name,
                int             timeout_ms
                );
#endif
