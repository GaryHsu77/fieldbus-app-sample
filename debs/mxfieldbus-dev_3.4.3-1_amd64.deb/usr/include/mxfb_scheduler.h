#ifndef MX_SCHEDULER_H 
#define MX_SCHEDULER_H

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

typedef enum {
    SCHEDULER_INIT  = 0,
    SCHEDULER_START = 1,
    SCHEDULER_PAUSE = 2,
    SCHEDULER_EXIT  = 3
} Scheruler_status;

typedef  int    (*SCHEDULER_START_CALLBACK)       (void *this);
typedef  int    (*SCHEDULER_STOP_CALLBACK)        (void *this);
typedef  void   (*SCHEDULER_POLLING_CALLBACK)     (void *this);

#pragma pack (1)
typedef struct
{
    char                            *name;
    int                             need_lock;
    int                             polling_period_ms;
    pthread_t                       scheduler_thread;
    pthread_mutex_t                 *mutex;
    Scheruler_status                status;
    SCHEDULER_START_CALLBACK        start;
    SCHEDULER_STOP_CALLBACK         stop;
    SCHEDULER_POLLING_CALLBACK      polling_callback;
    void*                           arg;
} Polling_scheduler;
#pragma pack ()

int Polling_scheduler_init (
        Polling_scheduler           *scheduler,
        char                        *name,
        int                         need_lock,
        pthread_mutex_t             *mutex,
        SCHEDULER_POLLING_CALLBACK  polling_callback,
        void                        *arg,
        int                         polling_period_ms
        );

int Polling_scheduler_start (
        void *this
        );

int Polling_scheduler_close (
        void *this
        );
#endif