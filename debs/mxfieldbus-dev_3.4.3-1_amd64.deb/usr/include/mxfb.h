#ifndef MX_FB_H 
#define MX_FB_H

#include "mxtagf.h"
                            
                            
#define VALUE_INVALID -1
#pragma pack (1)
typedef struct
{   
    value_type_t    type_t;
    int             size;
    uint8_t         *payload;
} Value;
#pragma pack ()

typedef enum {
    MXFB_READ,
    MXFB_WRITE,
    MXFB_RW,
    MXFB_TEST,
    MXFB_STATUS
} Operate_t;
#endif
