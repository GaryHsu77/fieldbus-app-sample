import sys
import re
import json

#argv[1] - script file
#argv[2] - template makefile
#argv[3] - fieldbus name
#argv[4] - output makefile

def main(argv):
    
    print 'make %s by %s' % (argv[1], argv[0]) 

    protcol_json = './' + argv[2] + '/protocol.json'
    with open(protcol_json) as f:
        protocol_json = json.loads(f.read())
    
    with open(argv[0]) as f:
        temp_lines = f.readlines()
        temp_lines = [re.sub('(\n)', '', x) for x in temp_lines] 
    
    out_f = open(argv[1], 'w')
    for L in temp_lines:
        if (L.strip() == "@MASTER_EXE_NAME"):
            out_f.write('MASTER_EXE_NAME = ' + protocol_json['serviceName'] + '\n')
            continue
        if (L.strip() == "@PROTOCOL_NAME"):
            out_f.write('PROTOCOL_NAME = ' + protocol_json['protocolName'] + '\n')
            continue
        if (L.strip() == "@CONFIG_PATH"):
            out_f.write('MASTER_CONFIG_PATH = ' + protocol_json['configPath'] + '\n')
            continue
        if (L.strip() == "@VERSION"):
            out_f.write('MASTER_VERSION = ' + protocol_json['version'] + '\n')
            continue
        out_f.write(L + '\n');

if __name__ == "__main__":
    main(sys.argv[1:])