import sys
import re
import json

#argv[1] - script file
#argv[2] - bundle.py template file
#argv[3] - mxfb_bundle.py template file
#argv[4] - config file
#argv[5] - output bundle.py
#argv[6] - output mxfb_bundle.py
#argv[7] - fieldbus name

def main(argv):
    
    print 'make %s by %s %s %s' % (argv[1], argv[0], argv[2], argv[3]) 
    
    protcol_json = './' + argv[3] + '/protocol.json'
    with open(protcol_json) as f:
        protocol_json = json.loads(f.read())
        
    with open(argv[2]) as f:
        cfg_json = json.loads(f.read())
    
    # fieldbus.py -----------------------------------------------
    with open(argv[0]) as f:
        fb_lines = f.readlines()
        fb_lines = [re.sub('(\n|\r)', '', x) for x in fb_lines] 
    
    tag_check_string = ''
    for item in cfg_json['tag']:
        if ('required' in item['attribute']):
            tag_check_string += ('        if not (\'' + item['name'] + '\' in tag_jobj): \n')
            tag_check_string += ('            print \'' + item['name'] + ' is not exist in tag json context.\'\n')
            tag_check_string += ('            return -1\n')
            
    out_f = open(argv[1], 'w')
    for L in fb_lines:
        if (L.strip() == "@exe_name"):
            out_f.write('        self.exe_name = \'' + protocol_json['serviceName'] + '\'\n')
            continue
        if (L.strip() == "@exe_path"):
            out_f.write('        self.exe_path = \'/usr/sbin/\'\n')
            continue
        if (L.strip() == "@conf_path"):
            out_f.write('        self.config_path = \'' + protocol_json['configPath'] + '\'\n')
            continue
        if (L.strip() == "@include_fieldbus_equ_item"):
            equ_item_string = ''
            for item in cfg_json['device']:
                if ('required' in item['attribute']):
                    if (item['type'] == 'string'):
                        equ_item_string += '    \"' + item['name'] + '\" : "",\n'
                    elif (item['type'] == 'double'):
                        equ_item_string += '    \"' + item['name'] + '\" : 0.0,\n'
                    else:
                        equ_item_string += '    \"' + item['name'] + '\" : 0,\n'
            out_f.write(equ_item_string[:-2] + '\n')
            continue
        
        if (L.strip() == "@include_fieldbus_tag_item"):
            tag_item_string = ''
            for item in cfg_json['tag']:
                if ('required' in item['attribute']):
                    if (item['type'] == 'string'):
                        tag_item_string += '    \"' + item['name'] + '\" : "",\n'
                    elif (item['type'] == 'double'):
                        tag_item_string += '    \"' + item['name'] + '\" : 0.0,\n'
                    else:
                        tag_item_string += '    \"' + item['name'] + '\" : 0,\n'
            out_f.write(tag_item_string[:-2] + '\n')
            continue
        
        if (L.strip() == "@include_fieldbus_tag_check"):
            out_f.write(tag_check_string)
            continue
            
        out_f.write(L + '\n')
    
if __name__ == "__main__":
    main(sys.argv[1:])