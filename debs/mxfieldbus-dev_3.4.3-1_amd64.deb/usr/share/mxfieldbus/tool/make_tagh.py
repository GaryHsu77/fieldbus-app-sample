import sys
import re
import json

#argv[1] - script file
#argv[2] - template file
#argv[3] - config file
#argv[4] - output header file

def main(argv):
    
    print 'make %s by %s' % (argv[2], argv[1])

    with open(argv[0]) as f:
        temp_lines = f.readlines()
        temp_lines = [re.sub('(\n)', '', x) for x in temp_lines] 
    
    with open(argv[1]) as f:
        cfg_json = json.loads(f.read())
    
    out_f = open(argv[2], 'w')
    for L in temp_lines:
        if (L.strip() == "@include_fieldbus_tag_item"):
            for item in cfg_json['tag']:
                if not ('default' in item['attribute']):
                    type_str = "int"
                    if (item['type'] == "string"):
                        type_str = "char*"
                    if (item['type'] == "double"):
                        type_str = "double"
                    out_f.write('    ' + type_str.ljust(20) + item['name'] + ';\n');
            continue
        out_f.write(L + '\n');

if __name__ == "__main__":
    main(sys.argv[1:])