import sys
import os
import json

#argv[1] - script file
#argv[2] - template file
#argv[3] - config file
#argv[4] - output header file

config_tmp = './template/protocol_tmp.json'

def main(argv):
    
    dist = './' + argv[0] + '/protocol.json'
    print 'make %s project' % (argv[0])

    if os.path.exists('./' + argv[0]):
        print 'Folder[./%s] already exists.' %(argv[0])
        return -1
        
    os.makedirs('./' + argv[0])
    
    with open(config_tmp) as f:
        cfg_json = json.loads(f.read())
        
    cfg_json['protocolName'] = argv[0]
    cfg_json['serviceName'] = argv[0] + 'master'
    cfg_json['configPath'] = '/etc/' + argv[0] + 'master/'
    
    with open(dist, 'w') as outfile:
        json.dump(cfg_json, outfile, indent=4)
    
    return 0

if __name__ == "__main__":
    main(sys.argv[1:])